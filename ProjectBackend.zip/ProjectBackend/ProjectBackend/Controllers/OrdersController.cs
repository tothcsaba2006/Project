﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectBackend.Models;

namespace ProjectBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetOrders()
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    var orders = cx.Orders.ToList();
                    return Ok(orders);
                }
                catch (Exception ex)
                {
                    return StatusCode(406, ex.Message);
                }
            }
        }
        [HttpPost]
        public IActionResult PostOrder(Order order)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Orders.Add(order);
                    cx.SaveChanges();
                    return Ok(order);
                }
                catch (Exception ex)
                {
                    return StatusCode(407, ex.Message);
                }
            }
        }
        [HttpPut]
        public IActionResult PutOrder(Order order)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Orders.Update(order);
                    cx.SaveChanges();
                    return Ok(order);
                }
                catch (Exception ex)
                {
                    return StatusCode(408, ex.Message);
                }
            }
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteOrder(int id)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Orders.Remove(new Order { Id = id });
                    cx.SaveChanges();
                    return Ok("a rendeles torolve lett");
                }
                catch (Exception ex)
                {
                    return StatusCode(409, ex.Message);
                }
            }
        }
    }
}