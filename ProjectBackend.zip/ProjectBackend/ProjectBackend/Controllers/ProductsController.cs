﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectBackend.Models;

namespace ProjectBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetProducts()
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    var products = cx.Products.ToList();
                    return Ok(products);
                }
                catch (Exception ex)
                {
                    return StatusCode(406, ex.Message);
                }
            }
        }
        [HttpPost]
        public IActionResult PostProduct(Product product)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Products.Add(product);
                    cx.SaveChanges();
                    return Ok(product);
                }
                catch (Exception ex)
                {
                    return StatusCode(407, ex.Message);
                }
            }
        }
        [HttpPut]
        public IActionResult PutProduct(Product product)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Products.Update(product);
                    cx.SaveChanges();
                    return Ok(product);
                }
                catch (Exception ex)
                {
                    return StatusCode(408, ex.Message);
                }
            }
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Products.Remove(new Product { Id = id });
                    cx.SaveChanges();
                    return Ok("a termek torolve lett");
                }
                catch (Exception ex)
                {
                    return StatusCode(409, ex.Message);
                }
            }
        }
    }
}