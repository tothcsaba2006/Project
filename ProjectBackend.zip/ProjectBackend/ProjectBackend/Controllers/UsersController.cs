﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectBackend.Models;

namespace ProjectBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetUsers()
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    var users = cx.Users.ToList();
                    return Ok(users);
                }
                catch (Exception ex)
                {
                    return StatusCode(406, ex.Message);
                }
            }
        }
        [HttpPost]
        public IActionResult PostUser(User user)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Users.Add(user);
                    cx.SaveChanges();
                    return Ok(user);
                }
                catch (Exception ex)
                {
                    return StatusCode(407, ex.Message);
                }
            }
        }
        [HttpPut]
        public IActionResult PutUser(User user)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Users.Update(user);
                    cx.SaveChanges();
                    return Ok(user);
                }
                catch (Exception ex)
                {
                    return StatusCode(408, ex.Message);
                }
            }
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Users.Remove(new User { Id = id });
                    cx.SaveChanges();
                    return Ok("a felhasznalo torolve lett");
                }
                catch (Exception ex)
                {
                    return StatusCode(409, ex.Message);
                }
            }
        }
    }
}