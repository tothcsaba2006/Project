﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectBackend.Models;

namespace ProjectBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetCart()
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    var carts = cx.Carts.ToList();
                    return Ok(carts);
                }
                catch (Exception ex)
                {
                    return StatusCode(406, ex.Message);
                }
            }
        }
        [HttpPost]
        public IActionResult PostCart(Cart cart)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Carts.Add(cart);
                    cx.SaveChanges();
                    return Ok(cart);
                }
                catch (Exception ex)
                {
                    return StatusCode(407, ex.Message);
                }
            }
        }
        [HttpPut]
        public IActionResult PutCart(Cart cart)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Carts.Update(cart);
                    cx.SaveChanges();
                    return Ok(cart);
                }
                catch (Exception ex)
                {
                    return StatusCode(408, ex.Message);
                }
            }
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteCart(int id)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Carts.Remove(new Cart { Id = id });
                    cx.SaveChanges();
                    return Ok("a kosar tartalma torolve lett");
                }
                catch (Exception ex)
                {
                    return StatusCode(409, ex.Message);
                }
            }
        }
    }
}