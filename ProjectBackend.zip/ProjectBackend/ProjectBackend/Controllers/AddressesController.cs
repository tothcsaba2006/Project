﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectBackend.Models;

namespace ProjectBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressesController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetAddresses()
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    var addresses = cx.Addresses.ToList();
                    return Ok(addresses);
                }
                catch (Exception ex)
                {
                    return StatusCode(406, ex.Message);
                }
            }
        }
        [HttpPost]
        public IActionResult PostAddress(Address address)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Addresses.Add(address);
                    cx.SaveChanges();
                    return Ok(address);
                }
                catch (Exception ex)
                {
                    return StatusCode(407, ex.Message);
                }
            }
        }
        [HttpPut]
        public IActionResult PutAddress(Address address)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Addresses.Update(address);
                    cx.SaveChanges();
                    return Ok(address);
                }
                catch (Exception ex)
                {
                    return StatusCode(408, ex.Message);
                }
            }
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteAddress(int id)
        {
            using (var cx = new WebshopContext())
            {
                try
                {
                    cx.Addresses.Remove(new Address { Id = id});
                    cx.SaveChanges();
                    return Ok("a cim torolve lett");
                }
                catch (Exception ex)
                {
                    return StatusCode(409, ex.Message);
                }
            }
        }
    }
}