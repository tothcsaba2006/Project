﻿using System;
using System.Collections.Generic;

namespace ProjectBackend.Models;

public partial class Address
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public string? Street { get; set; }

    public string? City { get; set; }

    public string? Zip { get; set; }

    public string? Country { get; set; }

    public virtual User User { get; set; } = null!;
}
